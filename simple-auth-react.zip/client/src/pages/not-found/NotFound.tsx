import React from "react";

const NotFound: React.FC = (): JSX.Element => {
  return (
    <div>
      <h1>Oops, We can't find your page!</h1>
    </div>
  );
};

export default NotFound;
